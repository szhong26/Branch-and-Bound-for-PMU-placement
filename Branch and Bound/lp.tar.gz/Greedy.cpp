//
//  Greedy.cpp
//  Branch and Bound
//
//  Created by Sichen Zhong on 3/18/15.
//  Copyright (c) 2015 Sichen Zhong. All rights reserved.
//

#include "Greedy.h"
#include "vector"
#include "math.h"
#include "unordered_set"
#include "iostream"
#include "limits"


using namespace std;

//DEFAULT CONSTRUCTOR
//-------------------------------------------------------------------------------------------------------------
Greedy::Greedy ():ObjVal(0){}

//-------------------------------------------------------------------------------------------------------------

//-Greedy function takes in number of buses, size of subset we are allowed to take, and a n by m square matrix where each column is a theta vector denoting the phase angle readings at each of the n buses.
//-entry (i,j) in matrix theta represents the phase angle reading of bus i for line break event j
//-M is the size of the number of buses we pick
//-float p is the type of norm

//SET PRIVATE MEMBERS U,P,ObjVal
//-------------------------------------------------------------------------------------------------------------
//Convert the path vector from a Node to 2 sets U and P

void Greedy::Convert(vector<int> path) //Note that every value in the path of a node is between 1 and bigtheta.size. However, Greedy calculates from 0 to bigtheta.size - 1. Hence, we need to subtract 1 from every bus in the path of a node. 
{
    this->DefaultU(); //U initially contains all buses from 0 to bigtheta.size()-1 ***PROBLEM WITH CONVERT?***
    
    for(vector<int>::iterator it = path.begin(); it != path.end(); it++)
    {
        if(*it>0)
        {
            P.insert(*it-1);
            U.erase(*it-1);
        }
        
        else if(*it<0)
        {
            U.erase(-(*it+1));
        }
    }
}

void Greedy::setP(unordered_set<int>& manualP)
{
    P = manualP;
}


void Greedy::setU(unordered_set<int>& manualU)
{
    U = manualU;
}

void Greedy::DefaultU()
{
    for(int i=0; i<totalbus; i++)
    {
        U.insert(i);
    }
    
}

void Greedy::setp(int norm)
{
    p = norm;
}


void Greedy::setM(int bussize)
{
    M = bussize;
}

void Greedy::settotalbus(unsigned long totalbussize)
{
    totalbus = totalbussize;
}

void Greedy::CalcObjVal(const vector<vector<double>> &bigtheta)
{
    double CurrentMin=0;
    
    for(int i=0; i!=bigtheta[0].size(); i++)
    {
        double PartialSum=0;
        
        for(unordered_set<int>::iterator it3 = P.begin(); it3 !=P.end(); it3++)
        {
            PartialSum = PartialSum + bigtheta[*it3][i];
        }
        
        if (i==0)
        {
            CurrentMin = PartialSum;
        }
        
        else if(i>0 && CurrentMin>PartialSum)
        {
            CurrentMin = PartialSum;
        }
    }
    
    ObjVal = CurrentMin;
}
//-------------------------------------------------------------------------------------------------------------

//GET PRIVATE MEMBERS
//-------------------------------------------------------------------------------------------------------------
double Greedy::getObjValue()
{
    return ObjVal;
}
const unordered_set<int>& Greedy::getU()const
{
    return U;
}
const unordered_set<int>& Greedy::getP()const 
{
    return P;
}
//-------------------------------------------------------------------------------------------------------------


//GREEDY ALGORITHM CALCULATIONS
//-------------------------------------------------------------------------------------------------------------
//Calculate the set of buses we need to choose and returns them as a vector. Remember that for each iteration of branch and bound, some buses are forced to be chosen and others are not. (These buses we are forced to take and not take is called a constraint set)

void Greedy::GreedyAlg(const vector<vector<double>> &bigtheta)

{
    int b;
    
    while(P.size()!=M)
    {
        b=Nextbus(bigtheta);
        
        /*
        cout<<"The next bus we should take is: "<<b<<endl;
        //--------------------------------------------------------------------------
        cout<<"P BEFORE INSERTION contains: ";
        for(unordered_set<int>::iterator it=P.begin(); it!=P.end(); it++)
        {
            cout<<" "<<*it;
        }
        cout<<endl;
        //--------------------------------------------------------------------------
        */
        
        
        P.insert(b);
        
        /*
        //--------------------------------------------------------------------------
        cout<<"P AFTER INSERTION contains: ";
        for(unordered_set<int>::iterator it=P.begin(); it!=P.end(); it++)
            {
                cout<<" "<<*it;
            }
        cout<<endl;
        //--------------------------------------------------------------------------
        
        
        //--------------------------------------------------------------------------
        cout<<"U BEFORE DELETION contains: ";
        for(unordered_set<int>::iterator it=U.begin(); it!=U.end(); it++)
        {
            cout<<" "<<*it;
        }
        
        cout<<endl;
        //--------------------------------------------------------------------------
        */
        
        
        U.erase(b);
        
        /*
        //--------------------------------------------------------------------------
        cout<<"U AFTER DELETION contains: ";
        for(unordered_set<int>::iterator it=U.begin(); it!=U.end(); it++)
        {
            cout<<" "<<*it;
        }
        
        cout<<endl;
        //--------------------------------------------------------------------------
        */
    }
    
    this->CalcObjVal(bigtheta);
}


//Nextbus takes in current set of buses, and the phase angle matrix to find the next bus to pick. Returns the next bus we should pick as an integer
//P is the current list of processed buses, U is the list of unprocessed buses, p is the type of norm

int Greedy::Nextbus(const vector<vector<double>> &bigtheta)

{
    double CurrentMin;
    double CurrentMax;
    double PartialSum;
    double temp;
    int bus=-1;
    
    CurrentMax=0;
     
    for(unordered_set<int>::iterator it = U.begin(); it != U.end(); it++)
    {
        CurrentMin=0;
     
        for(int i=0; i!=bigtheta[*it].size(); i++)
        {
            PartialSum=0;
     
            for(unordered_set<int>::iterator it3 = P.begin(); it3 !=P.end(); it3++)
            {
                PartialSum = PartialSum + bigtheta[*it3][i];
            }
            
            temp = PartialSum + bigtheta[*it][i];
            
            if (i==0)
            {
                CurrentMin = temp;
            }
            
            else if(i>0 && CurrentMin>temp)
            {
                CurrentMin = temp;
            }

        }
        
        
        if (CurrentMax <= CurrentMin)
        {
            CurrentMax = CurrentMin;
            
            bus=*it;
        }
    }
    
    return bus;
}
//-------------------------------------------------------------------------------------------------------------


