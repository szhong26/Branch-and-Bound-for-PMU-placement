//
//  Run.cpp
//  Branch and Bound
//
//  Created by Sichen Zhong on 4/20/15.
//  Copyright (c) 2015 Sichen Zhong. All rights reserved.
//

#include "Run.h"
#include "Global.h"
#include "vector"
#include "math.h"
#include "iostream"
#include "LP.h"
#include "Greedy.h"
#include "glpk.h"
#include "sstream"
#include "queue"
#include "unordered_set"

//RUN THE ALGORITHM
//-----------------------------------------------------------------------------------------------------------

void Run::BranchandBound(const vector<vector<double>>& theta, int norm, int M, double epsilon)//***********WORKING ON THIS************ DO SOME TESTING WHEN SETTING UP UPPER AND LOWER FOR ROOT!!!!
{
    
    cout<<"Initializing Algorithm..."<<endl;
    cout<<endl;
    //-----------------------------------------------------------------------------------------------------------
    Global temp; //Note that when we declare object temp, init() is run, so size ia, ja, and A are set
    
    //set all private members of temp
    //first define the given inputs
    temp.setM(M);
    temp.setNorm(norm);
    temp.settheta(theta);
    //temp.setbigtheta();
    temp.setbigtheta2(theta);
    //-line 1 below initializes the sizes of arrays ia, ja, and A.
    //-line 2 below initializes and creates the problem baseProb along with all the fixed constraints. For the base case, we assume all w_i's are between 0 and 1.
    temp.init();
    temp.setglpbase();
    //-----------------------------------------------------------------------------------------------------------
    cout<<"Global instance setup complete"<<endl;
    cout<<endl;
    cout<<"Constructing root Node..."<<endl;
    cout<<endl;
    //-----------------------------------------------------------------------------------------------------------
    //Initialize root and declare variables before constructing Branch and Bound Tree. We run Greedy first to find the first bus picked. This is our root node.
    //Find the first bus for the root
    
    Greedy begin;
    
    begin.setM(1);
    begin.setp(temp.getnorm());
    begin.settotalbus(temp.getBigTheta().size());
    begin.DefaultU();
    unordered_set<int> P_init;
    begin.setP(P_init);
    int startbus=(begin.Nextbus(temp.getBigTheta()))+1;  //The +1 is because the buses chosen by greedy start from bus 0 to N-1 instead of 1 to N.
    
    //Define the root node. All private parameters of root are by default set to NULL or empty. See node default constructor for more details
    //Note that if we write Node* root, the default constructor is NOT called, so no space is allocated for private members
    //If we need to call Global::Expand, we write temp.Expand(&root);
    
    
    Node* root = new Node();
    //PICK UP HERE NEXT TIME FOR CODE CHECKING
    root->setPath({startbus});
    root->setUpper(temp.getBigTheta(), temp.getProb(), temp.getia(), temp.getja(), temp.getA(), temp.getsize(), temp.getM());
    root->setLower(temp.getBigTheta(), temp.getnorm(), temp.getM()); //firstbus is set in Node::setLower, so no need to set it here for root
    
    //-----------------------------------------------------------------------------------------------------------
    
    cout<<endl;
    cout<<"Root Node setup complete"<<endl;
    cout<<endl;
    cout<<"Initializing global maxupper bound and maxlower bound(root)..."<<endl;
    cout<<endl;
    
    //Manually set/Initialize MaxUpper Node and MaxLower Node
    //-----------------------------------------------------------------------------------------------------------
    temp.setMaxUpper(root);
    temp.setMaxLower(root);
    
    cout<<"Starting U_0 is: "<<temp.getMaxUpper()->getUpper()<<endl;
    cout<<"Starting L_0 is: "<<temp.getMaxLower()->getLower()<<endl;
    cout<<"Starting U_0 - L_0 is: "<<temp.getMaxUpper()->getUpper()-temp.getMaxLower()->getLower()<<endl;
    //-----------------------------------------------------------------------------------------------------------
    
    cout<<endl;
    cout<<"MaxUpper and MaxLower setup complete"<<endl;
    cout<<endl;
    cout<<"Constructing maxU heap..."<<endl;
    cout<<endl;
    //-----------------------------------------------------------------------------------------------------------
    //Define our maxU and maxL priority queues. In other words, we initiate the heap/priority queue here. Note that the set of lower bounds is only used in testing U_k -L_k. Priority queues are initially empty.
    
    priority_queue<Node*, vector<Node*>, compareUpper> maxU;
    
    maxU.push(root);

    
    vector<int> solution_path;
    //-----------------------------------------------------------------------------------------------------------
    
    cout<<"maxU initialization complete"<<endl;
    cout<<endl;
    cout<<endl;
    cout<<"Beginning main algorithm loop..."<<endl;
    cout<<endl;
    
    //ALGORITHM MAIN LOOP
    //-----------------------------------------------------------------------------------------------------------
    
    int iteration = 0;
    
    while((temp.getMaxUpper()->getUpper())-(temp.getMaxLower()->getLower())>epsilon)
    {
        //Make a copy of the node in maxU with the largest upper bound
        //With this copy, expand it into 2 new nodes. Update copy as the left node and create a new node that is the successor to copy
        //insert copy and copy->next()) back into maxU
        //------------------------------------------------
        Node* copy = (maxU.top());
        maxU.pop();
        
        temp.Expand(copy);
        maxU.push(copy);
        maxU.push(copy->next());

        //------------------------------------------------
        
        //Update MaxUpper and MaxLower for Global temp object
        //1)first update MaxLower by making 2 comparisons.
        //2)next update MaxUpper
        //------------------------------------------------
        if(temp.getMaxLower()->getLower() <= copy->getLower())
        {
            temp.setMaxLower(copy);
        }
        
        if(temp.getMaxLower()->getLower() <= copy->next()->getLower())
        {
            temp.setMaxLower(copy->next());
        }

        temp.setMaxUpper(maxU.top());
        //------------------------------------------------
        
        cout<<endl;
        cout<<"The current U_k is: "<<temp.getMaxUpper()->getUpper()<<endl;
        cout<<"The current L_k is: "<<temp.getMaxLower()->getLower()<<endl;
        cout<<"The current U_k - L_k is: "<<temp.getMaxUpper()->getUpper()-temp.getMaxLower()->getLower()<<endl;
        cout<<endl;
        
        iteration++;
        
        cout<<"End of iteration: "<<iteration<<endl;
        cout<<endl;
    }
    //-----------------------------------------------------------------------------------------------------------
    
    cout<<"Algorithm complete"<<endl;
    //-----------------------------------------------------------------------------------------------------------
    
    /*
    //THE BELOW SOMETIMES PRODUCES ERRORS....WHY?
    cout<<"The path obtained from maxLower at the last iteration is: ";
    
    for(vector<int>::iterator it=temp.getMaxLower()->getPath().begin(); it!=temp.getMaxLower()->getPath().end(); it++)
    {
        cout<<" "<<*it;
    }
    
    cout<<endl;
    */
    
}
//-----------------------------------------------------------------------------------------------------------


