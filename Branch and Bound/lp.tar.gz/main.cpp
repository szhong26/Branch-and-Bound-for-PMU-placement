//
//  main.cpp
//  Branch and Bound
//
//  Created by Sichen Zhong on 3/18/15.
//  Copyright (c) 2015 Sichen Zhong. All rights reserved.
//

#include "iostream"
#include "unordered_set"
#include "Greedy.h"
#include "vector"
#include "glpk.h"
#include "Node.h"
#include "fileIO.h"
#include "Global.h"
#include "sstream"
#include "Run.h"
#include "string"
#include "fstream"

using namespace std;


int main()

{
    
    
    //INPUT TEST MATRIX
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    string file("/Users/sichenzhong/Desktop/Sichen/Graduate School/Algorithms/Code/Branch and Bound/Branch and Bound/matrix.txt");
    vector<vector<double>> mat;
    loadMatrix(file,mat);
    cout<<endl;
    
    
    int p = 2;
    int M = 2;
    //vector<vector<double>> theta2 {{4,4,4}, {2,2,2}, {0,2,1}};
    //vector<vector<double>> theta2 = {{3,1,2,0},{0,7,4,2},{2,0,8,3},{4,7,10,10}};
    vector<vector<double>> theta2 = mat;
    //vector<int> path = {1, -2, 3, -4, -5,-8, 12, 17, 30};
    
    unordered_set<int> P;
    
    
    
    
    //TESTING GREEDY FUNCTION/ SetLower
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    
    Global test;
    test.settheta(theta2);
    test.setNorm(p);
    //test.setbigtheta();
    test.setbigtheta2(theta2);
    //vector<vector<double>> bigtheta=test.getBigTheta();
    
    //cout<<test.getBigTheta()[28][660]<<endl;
    /*
    Node root;
    root.setPath({});
    root.setLower(test.getBigTheta(),p,M);
    
    cout<<"The objective value is: "<<root.getLower()<<endl;
    
    
    Greedy test2;
    test2.setM(M);
    test2.setp(p);
    test2.settotalbus(test.getBigTheta().size());
    
    test2.DefaultU();
    test2.setP(P);
    
    test2.GreedyAlg(test.getBigTheta());
     
    unordered_set<int> B = test2.getP();
     
    cout<<"The buses in our final solution are: ";
     
    for(unordered_set<int>::iterator it=B.begin(); it!=B.end(); it++)
    {
         
    cout<<" "<<*it+1;
     
    }
     
    cout<<endl;
    
    cout<<"The objective value is: "<<test2.getObjValue();
    
    */
    
    //Testing Global function/Upper bound function *****WORKING ON THIS********* WORKS!!!
    //---------------------------------------------------------------------------------------------------------------------------------------------
    /*
    
    
    Global temp;
    
    temp.setM(M); 
    temp.setNorm(p);
    //temp.settheta(theta2);
    temp.setbigtheta2(theta2);
    
    temp.init();
    temp.setglpbase();

    glp_load_matrix(temp.getProb(), temp.getsize(), temp.getia(), temp.getja(), temp.getA());
    glp_simplex(temp.getProb(), NULL);
    
    double z = glp_get_obj_val(temp.getProb());
    cout<<"Opt. is: "<<z<<endl;
    
    
    
    */
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    
    
    //Testing Global::BranchandBound
    //---------------------------------------------------------------------------------------------------------------------------------------------
    //multiplied bigtheta by 100 for this experiment
    
    Run::BranchandBound(theta2,p,11,0);
    
    
    
    
    
    
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    
    
    //Testing Paper Solution and calculating its objective value vs our objective value and opt solution
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    //unordered_set<int> P2 = {0,4,7,8,13,20,21,23,25,28};  //Paper Optimal
    
    //unordered_set<int> P3 = {24,20,6,23,12,3,19,7,22,27}; //Our Greedy Optimal/Global
    
    //unordered_set<int> P4 = {24,6,23,12,3,20,9,19,22,27}; //Our Branch and Bound Solution
    
    //The reason the below returns zero as objective value is because our OBJECTIVE VALUE ONLY CALCULATES THE INCREMENTAL OBJECTIVE GIVEN A SET P. SINCE THE SIZE OF DUMMY ALREADY EQUALS M, WE DO NOT EVEN ENTER THE LOOP!!!
    
    /*
    Greedy test2;
    test2.setM(M);
    test2.setp(p);
    test2.settotalbus(test.getBigTheta().size());
    test2.DefaultU();
    test2.setP(P);
    
    test2.GreedyAlg(test.getBigTheta());
    
    cout<<"The objective value using Convert method is: "<<test2.getObjValue()<<endl;
    */
    
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    
    //Testing Precision
    //---------------------------------------------------------------------------------------------------------------------------------------------
    /*
    double x=0.000000000009;
    
    if(x>0)
    {
        cout<<"yes"<<endl;
    }
    
    else
    {
    cout<<"no"<<endl;
    }
    */
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    //Further Testing of Lower Bounding Function M=7 iteration 3
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    /*
    Greedy temp5;
    temp5.setM(M);
    temp5.setp(p);
    temp5.settotalbus(test.getBigTheta().size());
    temp5.Convert({28});
    
    temp5.GreedyAlg(test.getBigTheta());
    
    cout<<temp5.getObjValue()<<endl;
    
    Greedy temp6;
    temp6.setM(M);
    temp6.setp(p);
    temp6.settotalbus(test.getBigTheta().size());
    
    unordered_set<int> Ptest = {27,22};
    unordered_set<int> Utest = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23,24,25,26,28,};
    temp6.setP(Ptest);
    temp6.setU(Utest);
    
    temp6.GreedyAlg(test.getBigTheta());
    
    cout<<temp6.getObjValue()<<endl;
    
    
  
    */
    
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    return 0;
    
}
