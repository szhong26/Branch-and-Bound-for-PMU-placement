//
//  Node.cpp
//  Branch and Bound
//
//  Created by Sichen Zhong on 4/1/15.
//  Copyright (c) 2015 Sichen Zhong. All rights reserved.
//

#include "Node.h"
#include "Greedy.h"
#include "vector"
#include "glpk.h"
#include "sstream"
#include "LP.h"
#include "unordered_set"
#include "iostream"
using namespace std;


//DEFAULT CONSTRUCTOR
//------------------------------------------------------------------------------------------------------------
Node::Node ():_prev(NULL),_next(NULL),firstbus(-1),upper(0),lower(0),path(){} //placing the default values in brackets is faster than placing them in the body of the function!!!!
//-------------------------------------------------------------------------------------------------------------


//NODE POINTER OPERATIONS
//------------------------------------------------------------------------------------------------------------
//Note that function parameters are passed by copy or by direct reference. If the input parameter was a node, then the function setNext first makes a copy of the node, then assigns _next to the address of the COPY(This is an expensive operation if the input parameter is a large object) However, when the function ends, the copy is destroyed, so _next would be pointing to something was destroyed!!! Hence, we must make a copy of the pointer to the succeeding node, then assign the copy to _next.

void Node::setNext(Node* successor)

{
    _next = successor;
}

void Node::setPrevious(Node* predecessor)
{
    _prev = predecessor;
}
//-------------------------------------------------------------------------------------------------------------


//RETRIEVE NODE PRIVATE VALUES
//-------------------------------------------------------------------------------------------------------------
int Node::getfirstbus(void)
{
    return firstbus;
}

double Node::getUpper(void)
{
    return upper;
}

double Node::getLower(void)
{
    return lower;
}

vector<int> Node::getPath(void)
{
    return path;
}
//--------------------------------------------------------------------------------------------------------------



//SET NODE PRIVATE VALUES. setPath SHOULD ALWAYS BE USED FIRST SINCE THE OTHERS ALL DEPEND ON PRIVATE MEMBER path
//--------------------------------------------------------------------------------------------------------------

void Node::setPath(vector<int> a)
{
    path = a;
}

void Node::setfirstbus2(int temp)
{
    firstbus = temp;
}

void Node::setfirstbus(const vector<vector<double>> &bigtheta, int norm)
{
    //Greedy::GreedyAlg(path(or in terms of U and P)returns a set of the buses we should take. Take the first element in that set and set it to firstbus. Generally, we do not need to call this function in a run of the program. This is because Greedy::Nextbus automatically updates the opitmal Greedy value everytime it is run.
    
     Greedy temp;
     temp.Convert(path);
     temp.setp(norm);
     firstbus = temp.Nextbus(bigtheta)+1; //Note that when Nextbus is run, ObjValue is also set for temp;
}

void Node::setUpper(const vector<vector<double>> &bigtheta, glp_prob* temp,int* ia,int *ja,double *A, int size, int M) 
//Takes in the baseProb and fixes certain w_i's according to the current path on the node
{
    //add additional constraints which fix some of the w_i's according to the path saved.
    //make a copy of the basic problem from global and assign it to NodeProb. NodeProb comes with additional constraints which fix certain w_i's of the basic problem
    
    glp_prob* NodeProb;
    
    NodeProb = glp_create_prob();
    
    glp_copy_prob(NodeProb, temp, GLP_ON);
    
    LP::ChangeWiConstraints(path, NodeProb, bigtheta.size());
    
    glp_load_matrix(NodeProb, size, ia, ja, A);
    
     glp_simplex(NodeProb, NULL);
    
    upper = glp_get_obj_val(NodeProb);
    
    double Partialsum=0;
    
    cout<<endl;
    cout<<"The corresponding solution is: ";
    
    for(int i = 1; i <= bigtheta.size(); i++)
    {
        cout<<"w_"<<i<<" = "<<glp_get_col_prim(NodeProb, i)<<"    ";
        Partialsum = Partialsum + glp_get_col_prim(NodeProb, i);
    }
    cout<<"The sum of the solutions is equal to: "<<Partialsum;
    
    cout<<endl;
    cout<<endl;
    
    glp_delete_prob(NodeProb);
}

void Node::setLower(const vector<vector<double>> &bigtheta, int norm, int M)
{
    //use Greedyalg class to set lower value(lower)
    //ex. lower = Greedy::ObjValue(path)
    //also finds the firstbus
    
    Greedy temp;
    temp.setM(M);
    temp.setp(norm);
    temp.settotalbus(bigtheta.size());
    temp.Convert(path);
    
    //The +1 is for the fact that path's and firstbus private variables are from 1 to bigtheta.size()
    firstbus = temp.Nextbus(bigtheta)+1; //CURRENTLY THIS IS A LITTLE SLOW, SINCE WE ARE FINDING FIRSTBUS TWICE. ONCE IN THIS LINE AND AGAIN IN THE NEXT LINE
    temp.GreedyAlg(bigtheta);
    
    
    lower = temp.getObjValue(); //ALSO REMEMBER THAT WE MULTIPLIED BIG THETA BY A CONSTANT TO ACCOUNT FOR PRECISION PROBLEMS IN UPPER BOUND FUNCTION. HENCE, IN OPTIMAL, WE NEED TO DIVIDE BY THE SAME CONSTANT IF WE WANT REAL SOLUTION. (SAME WITH U_k)

    cout<<"The buses chosen corresponding to the lower bound value for a particular node using Greedy is: ";
    
    for(unordered_set<int>::iterator it=temp.getP().begin(); it!=temp.getP().end(); it++)
    {
        cout<<" "<<*it+1;
    }
    
    cout<<endl;
    cout<<endl;
}

//--------------------------------------------------------------------------------------------------------------


//Overloading the boolean operator (<) for the priority queue in BranchandBound in Global
//--------------------------------------------------------------------------------------------------------------
bool compareUpper::operator()(Node* N1, Node* N2)
{
    if (N1->getUpper() < N2->getUpper())
    {
        return true;
    }
    
    return false;
}

bool compareLower::operator()(Node* N1, Node* N2)
{
    if (N1->getLower() < N2->getLower())
    {
        return true;
    }
    
    return false;
}