//
//  main.cpp
//  Branch and Bound
//
//  Created by Sichen Zhong on 3/18/15.
//  Copyright (c) 2015 Sichen Zhong. All rights reserved.
//

#include <iostream>
#include "fileIO.h"
#include "Run.h"


using namespace std;


int main(int argc, char* argv[])

{
    //INPUT TEST MATRIX
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    string file("/home/laozzzzz/Documents/cvx_project/matrix.txt");
    vector<vector<double>> mat;
    loadMatrix(file,mat);
    cout<<endl;
    int p = 2;
    int M = 15;
    if(argc >= 2)
        p = atoi(argv[1]);
    if(argc >= 3)
        M = atoi(argv[2]); //Note that M=5 in the paper is M=4 in our algorithm since we do not take into account the root node. Hence, add 1
    //vector<vector<double>> theta2 {{4,4,4}, {2,2,2}, {0,2,1}};
    //vector<vector<double>> theta2 = {{3,1,2,0},{0,7,4,2},{2,0,8,3},{4,7,10,10}};
    vector<vector<double>> theta2 = mat;
    //vector<int> path = {1, -2, 3, -4, -5,-8, 12, 17, 30};
    
    //unordered_set<int> P;
    
    
    
    
    //TESTING GREEDY FUNCTION/ SetLower
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    
    Global test;
    test.setM(M);
    test.setNorm(p);
    test.settheta(theta2);
    test.setNorm(p);
    //test.setbigtheta();
    test.setbigtheta2(theta2);
    
    //vector<vector<double>> bigtheta=test.getBigTheta();
    
    
    /*
    Node root;
    root.setPath({});
    root.setLower(test.getBigTheta(),p,M);
    
    cout<<"The objective value is: "<<root.getLower()<<endl;
    
    
    Greedy test2;
    test2.setM(M);
    test2.setp(p);
    test2.settotalbus(test.getBigTheta().size());
    
    test2.DefaultU();
    test2.setP(P);
    
    test2.GreedyAlg(test.getBigTheta());
     
    unordered_set<int> B = test2.getP();
     
    cout<<"The buses in our final solution are: ";
     
    for(unordered_set<int>::iterator it=B.begin(); it!=B.end(); it++)
    {
         
    cout<<" "<<*it+1;
     
    }
     
    cout<<endl;
    
    cout<<"The objective value is: "<<test2.getObjValue();
    
    */
    
    //Testing Global function/Upper bound function *****WORKING ON THIS********* WORKS!!!
    //---------------------------------------------------------------------------------------------------------------------------------------------
    /*
    
    
    Global temp;
    
    temp.setM(M); 
    temp.setNorm(p);
    //temp.settheta(theta2);
    temp.setbigtheta2(theta2);
    
    temp.init();
    temp.setglpbase();

    glp_load_matrix(temp.getProb(), temp.getsize(), temp.getia(), temp.getja(), temp.getA());
    glp_simplex(temp.getProb(), NULL);
    
    double z = glp_get_obj_val(temp.getProb());
    cout<<"Opt. is: "<<z<<endl;
    
    
    
    */
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    
    
    //Testing Global::BranchandBound
    //---------------------------------------------------------------------------------------------------------------------------------------------
    /*
    double epslon = 0.001;
    
    Run::BranchandBound(theta2,p,M,epslon);
    */
     
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    
    
    //Testing Paper Solution and calculating its objective value vs our objective value and opt solution
    //---------------------------------------------------------------------------------------------------------------------------------------------
    /*
    unordered_set<int> P2 = {15,27};  //Paper Optimal
unordered_set<int> U2 = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28};
    
    //unordered_set<int> P3 = {24,20,6,23,12,3,19,7,22,27}; //Our Greedy Optimal/Global
    
    //unordered_set<int> P4 = {24,6,23,12,3,20,9,19,22,27}; //Our Branch and Bound Solution
    
    //The reason the below returns zero as objective value is because our OBJECTIVE VALUE ONLY CALCULATES THE INCREMENTAL OBJECTIVE GIVEN A SET P. SINCE THE SIZE OF DUMMY ALREADY EQUALS M, WE DO NOT EVEN ENTER THE LOOP!!!
    
    
    Greedy test2;
    test2.setM(M);
    test2.setp(p);
    test2.settotalbus(test.getBigTheta().size());
    test2.setU(U2);
    test2.setP(P2);
    
    test2.GreedyAlg(test.getBigTheta());
    
    cout<<"The objective value using Convert method is: "<<test2.getObjValue()<<endl;
    */
    
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    
    //Testing Global Objective function and simplex algorithm ( SHOULD USE EXACT TO GET EXACT SIMPLEX SOLUTION )
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
    /*
    cout<<endl;
    cout<<endl;
    cout<<endl;
    cout<<endl;
    cout<<endl;
    
    vector<double> w = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; //vector w is from 0 to bigtheta.size() - 1
    w[3] = 1;
    w[6] = 1;
    w[7] = 1;
    w[12] = 1;
    w[19] = 1;
    w[20] = 1;
    w[21] = 1;
    w[22] = 1;
    w[23] = 1;
    w[24] = 1;
    w[27] = 1;
    double objective = CalcObj(w, test.getBigTheta());
    
    cout<<"The objective value for w is : "<<objective<<endl;
    
    
    vector<double> w1 = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; //vector w is from 0 to bigtheta.size() - 1
    
    double objective2 = CalcObj(w1, test.getBigTheta());
    
    cout<<"The objective value for w2 is : "<<objective2<<endl;
    */
    
    
    
    test.init();
    test.setglpbase();
    vector<int> w2 = {-1,-2,-3,4,-5,-6,7,8,9,-10,-11,-12,13,-14,-15,16,-17,-18,-19,20,21,22,23,24,25,26,-27,28,29};
    
    LP::ChangeWiConstraints(w2, test.getProb());
    glp_load_matrix(test.getProb(), test.getsize(), test.getia(), test.getja(), test.getA());
    glp_exact(test.getProb(), NULL);
    
    cout<<"The corresponding solution is: ";
    
    double Partialsum = 0;
    for(int i = 1; i <= test.getBigTheta().size(); i++)
    {
        cout<<"w_"<<i<<" = "<<glp_get_col_prim(test.getProb(), i)<<"    ";
        Partialsum = Partialsum + glp_get_col_prim(test.getProb(), i);
    }
    cout<<endl;
    cout<<"The objective value from Simplex with w2 as the path is : "<<glp_get_obj_val(test.getProb())<<endl;
    
    Greedy test3;
    test3.setM(M);
    test3.setp(p);
    test3.settotalbus(test.getBigTheta().size());
    test3.Convert(w2);
    
    test3.GreedyAlg(test.getBigTheta());
    
    cout<<endl;
    cout<<"The objective value from GreedyAlg with w2 as the path is: "<<test3.getObjValue()<<endl;
    
    for(auto it = test3.getP().begin(); it!=test3.getP().end(); it++)
    {
        cout<<" "<<*it;
    }
    
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
}
