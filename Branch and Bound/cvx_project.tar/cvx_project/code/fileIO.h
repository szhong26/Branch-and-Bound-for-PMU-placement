#ifndef FILEIO_H
#define FILEIO_H
#include "matrixloader.h"
void loadMatrix(string,vector< vector<double> >&);
#endif // FILEIO_H
