//
//  Run.h
//  Branch and Bound
//
//  Created by Sichen Zhong on 4/20/15.
//  Copyright (c) 2015 Sichen Zhong. All rights reserved.
//

#ifndef __Branch_and_Bound__Run__
#define __Branch_and_Bound__Run__

#include <stdio.h>
#include <vector>
#include <iostream>
#include <queue>
#include "Global.h"
#include <time.h>


using namespace std;

class Run

{
    
public:
    
    //USE THIS FUNCTION TO RUN THE WHOLE ALGORITHM
    //---------------------------------------------------------------------------------------------------------------------------------------------
    static void BranchandBound(const vector<vector<double>>& theta, int norm, int M, double epsilon);//***********WORKING ON THIS******
    //---------------------------------------------------------------------------------------------------------------------------------------------
    
};



#endif /* defined(__Branch_and_Bound__Run__) */
